﻿using System;
using System.Collections.Generic;
using System.Text;
using P03_Wild_Farm.Base;

namespace P03_Wild_Farm.Children
{
    public class Fruit : Food
    {
        public Fruit(int quantity) : base(quantity)
        {

        }
    }
}
