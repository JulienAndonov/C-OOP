﻿using System;
using System.Collections.Generic;
using System.Text;
using P03_Wild_Farm.Base;

namespace P03_Wild_Farm.Children
{
    public class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {

        }
    }
}
