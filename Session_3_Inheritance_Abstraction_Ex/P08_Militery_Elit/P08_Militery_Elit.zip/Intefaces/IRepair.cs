﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P08_Militery_Elite.Interfaces
{
    public interface IRepair
    {
        string PartName { get;}
        int HoursWorked { get;}
    }
}
