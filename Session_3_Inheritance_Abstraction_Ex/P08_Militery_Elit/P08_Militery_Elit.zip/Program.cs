﻿using P08_MilitaryElite.Core;
using System;
using System.Collections.Generic;

namespace P08_Militery_Elit
{
    class Program
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
