﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P08_Militery_Elite.Enums
{
    public enum State
    {
        inProgress = 1,
        Finished = 2
    }
}
