﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P07_Food_Shortage
{
    interface IIDable
    {
        string ID { get; set; }
    }
}
