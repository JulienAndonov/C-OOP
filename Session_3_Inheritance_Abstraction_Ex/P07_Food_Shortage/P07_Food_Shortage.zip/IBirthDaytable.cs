﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P07_Food_Shortage
{
    public interface IBirthDaytable
    {
        string BirthDate { get; set; }
    }
}
