﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04_Telephony
{
    public interface IBrowsing
    {
        string Browse(string webSite);
    }
}
