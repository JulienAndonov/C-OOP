﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04_Telephony
{
    public interface ICalling
    {
        string Call(string number);
    }
}
