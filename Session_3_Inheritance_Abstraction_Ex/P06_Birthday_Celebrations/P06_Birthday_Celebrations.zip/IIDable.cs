﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P06_Birthday_Celebrations
{
    interface IIDable
    {
        string ID { get; set; }
        string BirthDate { get; set; }
    }
}
