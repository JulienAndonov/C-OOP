﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P06_Birthday_Celebrations
{
    public interface IBirthDaytable
    {
        string BirthDate { get; set; }
    }
}
