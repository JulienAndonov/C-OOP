﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P05_BorderControl
{
    interface IIDable
    {
        string ID { get; set; }
    }
}
