﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnimalCentre.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
