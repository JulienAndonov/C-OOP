﻿namespace P04_StorageMaster.Entities.Vehicles
{
	public class Van : Vehicle
	{
		public Van()
			: base(capacity: 2)
		{
		}
	}
}