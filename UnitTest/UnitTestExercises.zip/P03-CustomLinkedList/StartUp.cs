﻿namespace P03_CustomLinkedList
{
    using System;

    public class StartUp
    {
        public static void Main()
        {

        }
    }
}
