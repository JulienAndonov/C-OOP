﻿namespace P04_Radio_Database
{
    using P04_OnlineRadioDatabase.Core;

    public class StartUp
    {
        public static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}